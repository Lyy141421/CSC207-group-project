Hello,

We've created a jobApplicationSystem application system using standard input. It doesn't require any files to run, but
it will create 2 directories while running to store data from the application system.

The file loading data into memory occurs when you click on run in IDE and saves only when the window is closed, not at
each logout.

Here are some things to look out for so that you don't run into any issues:
- You must create an interviewer in the specified job posting field before HR sets an interview configuration for a job posting
- When you log into HR and see the warning to not use the side bar menu, please do not ignore them because you will get
unexpected results otherwise
- When you get popups in HR do not close them, just follow through with it

Other notes:
- During our testing, each user main panel works as required, however, when put together, there are thread issues that
corrupt memory between each log-in, but within each run
- Furthermore, when you close the program and reopen it, because of the corrupt memory, the data is not stored properly
in the .ser files
- We worked extremely hard to solve and work around this issue, but we ultimately came up short



