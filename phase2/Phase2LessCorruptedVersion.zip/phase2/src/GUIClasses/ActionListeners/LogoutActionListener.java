package GUIClasses.ActionListeners;

import CompanyStuff.Branch;
import CompanyStuff.Company;
import CompanyStuff.JobPostings.BranchJobPosting;
import CompanyStuff.JobPostings.BranchJobPostingManager;
import FileLoadingAndStoring.DataLoaderAndStorer;
import GUIClasses.MainFrame;
import Main.JobApplicationSystem;
import Main.User;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class LogoutActionListener implements ActionListener {

    // === Instance variables ===
    private Container parent;
    private CardLayout masterLayout;

    public LogoutActionListener(Container parent, CardLayout masterLayout) {
        this.parent = parent;
        this.masterLayout = masterLayout;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        parent.remove(this.getUserPanelFromMenuItemDirectlyOnMenuBar(e));
        masterLayout.show(parent, MainFrame.LOGIN);
    }

    private JPanel getUserPanelFromMenuItemDirectlyOnMenuBar(ActionEvent e) {
        JMenuItem menuItem = (JMenuItem) e.getSource();
        JMenuBar sideBarMenu = (JMenuBar) menuItem.getParent();
        JPanel sideBarMenuPanel = (JPanel) sideBarMenu.getParent();
        return (JPanel) sideBarMenuPanel.getParent();
    }
}
